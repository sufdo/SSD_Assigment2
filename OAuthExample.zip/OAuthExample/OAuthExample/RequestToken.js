var express = require('express'),
	bodyParser = require('body-parser'),
	oauthserver = require('oauth2-server');

var app = express();

app.use(bodyParser.urlencoded({ extended: true }));

app.use(bodyParser.json());

app.oauth = oauthserver({
	model: require('./resource.js'),
	grants: ['password', 'client_credentials'],
	debug: true
});

app.all('/oauth/token', app.oauth.grant());

app.get('/userDetails', app.oauth.authorise(), function (req, res) {
	res.json({name:'admin' , id:'set'});
});

app.use(app.oauth.errorHandler());

app.listen(2000);
